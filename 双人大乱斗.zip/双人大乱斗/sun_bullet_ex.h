#pragma once

#include"bullet.h"
#include"animation.h"

extern Atlas atlas_sun_ex;
extern Atlas atlas_sun_ex_explode;

extern Camera main_camera;

class SunBulletEx : public Bullet
{
public:
	SunBulletEx();
	~SunBulletEx() = default;

	void on_collide();

	void on_update(int delta);

	void on_draw(const Camera& camera) const;

	bool check_collision(const Vector2& position, const Vector2& size);

private:
	//�޴��ӵ�Ĭ�϶���
	Animation animation_idle;
	//�޴��ӵ���ը����
	Animation animation_explode;
	//��ը������Ⱦƫ��
	Vector2 explode_render_offset;
};