#pragma once

#include<functional>

class Timer
{
public:
	Timer() = default;

	~Timer() = default;

	void restart();

	void set_wait_time(int val);

	void set_one_shot(bool flag);

	void on_update(int delta);

	void set_callback(std::function<void()> callback);

	void pause();

	void resume();

private:
	int pass_time = 0;			//�ѹ�ʱ��
	int wait_time = 0;			//�ȴ�ʱ��
	bool paused = false;		//�Ƿ���ͣ
	bool shotted = false;		//�Ƿ񴥷�
	bool one_shot = false;		//���δ���
	std::function<void()> callback;	//�����ص�
};
