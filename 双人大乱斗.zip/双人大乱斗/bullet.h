#pragma once

#include"vector2.h"
#include"camera.h"
#include"player_id.h"

#include<graphics.h>
#include<functional>

extern bool is_debug;

class Bullet
{
public:
	Bullet() = default;
	~Bullet() = default;

	void set_damage(int val);

	int get_damage();

	void set_position(float x, float y);

	const Vector2& get_position();

	const Vector2& get_size() const;

	void set_velocity(float x, float y);

	void set_collide_target(PlayerID target);

	PlayerID get_collide_target() const;

	void set_callback(std::function<void()> callback);

	void set_valid(bool flag);

	bool get_valid() const;

	bool check_can_remove() const;

	virtual void on_collide();

	virtual bool check_collision(const Vector2& position, const Vector2& size);

	virtual void on_update(int ddelta) { };

	virtual void on_draw(const Camera& camera)const;

protected:
	//�ӵ��ߴ�
	Vector2 size;
	//�ӵ�λ��
	Vector2 position;
	//�ӵ��ٶ�
	Vector2 velocity;
	//�ӵ��˺�
	int damage = 10;
	//�ӵ��Ƿ���Ч
	bool valid = true;
	//�ӵ��Ƿ���Ա��Ƴ�
	bool can_remove = false;
	//�ӵ���ײ�ص�����
	std::function<void()> callback;
	//�ӵ���ײĿ�����ID
	PlayerID target_id = PlayerID::P1;

protected:
	virtual bool check_if_exceed_screen();
};
